import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> marks = new ArrayList<>();
        marks.add(12);
        marks.add(8);
        marks.add(5);
        marks.add(10);
        marks.add(3);

        System.out.println("Усі оцінки:");

        for (int mark : marks) {
            System.out.println(mark);
        }


        System.out.println("\nУсі очінки більші або рівні 8");

        int c = 0;
        for (int mark : marks) {
            if (mark >= 8) {
                System.out.println(mark);
                c += 1;
            }
        }

        System.out.printf("\nКількість оцінок, які більші обо дорівнюють 8: %s", c);
    }
}
