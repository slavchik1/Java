public class Main {
    public static void main(String[] args) {
        Animal[] animals = new Animal[2];
        Cat cat = new Cat();
        animals[0] = cat;
        Dog dog = new Dog();
        animals[1] = dog;

        for (Animal animal : animals) {
            animal.makeSound();
        }
    }
}
