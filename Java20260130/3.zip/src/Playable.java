interface Playable {
    void play();
}
