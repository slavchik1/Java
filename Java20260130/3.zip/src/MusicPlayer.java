class MusicPlayer implements Playable {
    private String song;

    public MusicPlayer(String song) {
        this.song = song;
    }

    @Override
    public void play() {
        System.out.println(song);
    }
}

