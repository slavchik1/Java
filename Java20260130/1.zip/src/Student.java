class Student extends Person {
    private final String group;

    public Student(String name, int age, String group) {
        super(name, age);
        this.group = group;
    }

    @Override
    public String toString() {
        return "Імʼя: " + this.name + "\nВік: " + Integer.toString(age) + "\nГрупа: " + this.group + "\n";
    }
}
